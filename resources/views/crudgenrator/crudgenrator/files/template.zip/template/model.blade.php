<{{ $data['wildcard'] }}php
/**
 * Class {{ $data['model'] }}
 *
 * @category zStarter
 *
 * @ref zCURD
 * @author  Defenzelite <hq@defenzelite.com>
 * @license https://www.defenzelite.com Defenzelite Private Limited
 * @version <zStarter: 1.1.0>
 * @link    https://www.defenzelite.com
 */

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
@if(isset($data['softdelete']))
use Illuminate\Database\Eloquent\SoftDeletes;
@endif @foreach($data['fields']['name'] as $index => $item)@if($data['fields']['input'][$index] == 'select_via_table')
@php if($data['fields']['table'][$index] == "User") $model_path = "App\\";  else $model_path = "App\Models\\"; @endphp
use {{ $model_path }}{{ $data['fields']['table'][$index] }};
@endif @endforeach


class {{ $data['model'] }} extends Model
{
    use HasFactory;
    @if(isset($data['softdelete']))use SoftDeletes;@endif

    protected $guarded = ['id'];

    public function getPrefix() {
        return "#{{ preg_replace('~[^A-Z]~', '', $data['model']) }}".str_replace('_1','','_'.(100000 +$this->id));
    }
    @foreach($data['fields']['name'] as $index => $item)
    @if($data['fields']['input'][$index] == 'select_via_table')
    public function  {{ lcfirst(str_replace('Id','',ucwords(str_replace('_','',$item)))) }}(){
        $this->belongsTo({{ $data['fields']['table'][$index] }}::class,'{{ $item }}','id');
    }
    @endif
    @endforeach
}
