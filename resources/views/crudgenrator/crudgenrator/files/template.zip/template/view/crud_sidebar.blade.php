<div class="nav-item {{ $data['curlstart'] }} ($segment2 == '{{ $segment }}') ? 'active' : '' }}">
    <a href="{{$data['curlstart']}} route('{{$as}}.index')}}" class="a-item" ><i class="ik ik-user-x"></i><span>{{ $heading}}</span></a>
</div> 
